using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Vector3 jump;
    public float jumpHeight = 2f;
    public float Speed = 4;
    float movementSpeed;
    public bool isGrounded;
    private Rigidbody playerRB;
    // Start is called before the first frame update
    void Start()
    {
        movementSpeed = 4;
        jump = new Vector3(0,2,0);
        playerRB=GetComponent<Rigidbody>();
    }

    void OnCollisionStay()
    {
        isGrounded = true;
    }
    // Update is called once per frame
    void Update()
    {

         if (Input.GetKey(KeyCode.W))
       {
              transform.Translate(movementSpeed*Time.deltaTime,0,0);
       }

       if (Input.GetKey(KeyCode.A))
       {
              transform.Translate(0,0,movementSpeed*Time.deltaTime);
       }

       if (Input.GetKey(KeyCode.S))
       {
              transform.Translate(-movementSpeed*Time.deltaTime,0,0);
       }

       if (Input.GetKey(KeyCode.D))
       {
              transform.Translate(0,0,-movementSpeed*Time.deltaTime);
       }

       if (Input.GetKey(KeyCode.Space) && isGrounded)
       {
             playerRB.AddForce(jump * jumpHeight, ForceMode.Impulse);
             isGrounded = false;
       }
    }
}
