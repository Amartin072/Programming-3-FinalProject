using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathPlane : MonoBehaviour
{
    public Transform spawnPoint;
    public float minDeathHeight;
    public GameObject player;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(player.transform.position.y < minDeathHeight)
        {
           player.transform.position = spawnPoint.position;
        }
    }

        void OnTriggerEnter(Collider other) 
    {
         if (other.gameObject.CompareTag("Player"))
         {
             player.transform.position = spawnPoint.transform.position;
         }
    }
}
