using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LimbMovement : MonoBehaviour
{
public float Speed = 4;
float limbSpeed;
private Rigidbody limbRB;
    // Start is called before the first frame update
    void Start()
    {
        limbSpeed = 4;
        limbRB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.I))
        {
            transform.Translate(limbSpeed*Time.deltaTime,0,0);
        }

         if (Input.GetKey(KeyCode.J))
        {
            transform.Translate(0,0,limbSpeed*Time.deltaTime);
        }

         if (Input.GetKey(KeyCode.K))
        {
            transform.Translate(-limbSpeed*Time.deltaTime,0,0);
        }
    }
}
